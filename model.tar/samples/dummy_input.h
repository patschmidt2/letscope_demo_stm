#include <stddef.h>
#include <stdint.h>
#include <dlpack/dlpack.h>
#define DUMMY_INPUT_LEN 5
int8_t dummy_input[] ={36, 42, 15, 38, 64, };

