#include <stddef.h>
#include <stdint.h>
#include <dlpack/dlpack.h>
#define EXPECTED_OUTPUT_LEN 1
int8_t expected_output[] ={72, };

